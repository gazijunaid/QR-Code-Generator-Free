# QR Code Generator - Design Guidelines

## Design Approach
**System-Based Approach**: Clean, functional design system emphasizing usability and clarity. Drawing inspiration from modern productivity tools like Linear and Notion for their balance of form and function.

## Core Design Principles
1. **Functional Clarity**: Every element serves a clear purpose
2. **Immediate Feedback**: Real-time validation and QR code preview
3. **Organized Workflow**: Guide users through input → customize → generate → save

---

## Typography System
- **Primary Font**: 'Inter' or 'DM Sans' from Google Fonts
- **Headings**: 24px/600 weight for main title, 18px/600 for section headers
- **Body Text**: 15px/400 for labels and descriptions
- **Small Text**: 13px/400 for helper text and validation messages
- **Creator Info**: 14px/500 for name, 13px/400 for link

## Layout System
**Spacing Units**: Use consistent spacing of `1rem`, `1.5rem`, `2rem`, `3rem`
- Component padding: `1.5rem` (24px)
- Section spacing: `2rem` (32px)
- Input field spacing: `1rem` (16px)
- Button padding: `0.75rem 1.5rem`

**Container Structure**:
- Max-width: `900px` centered layout
- Single column design for optimal workflow
- Responsive: Stack controls vertically on mobile (<640px)

---

## Component Library

### Layout Structure
1. **Header Section**
   - App title "QR Code Generator" (h1, centered)
   - Subtle description: "Generate custom QR codes for URLs and text"

2. **Main Control Panel** (card-style container with subtle border)
   - Input Mode Toggle (URL/Text) - segmented control style
   - Input Field (full-width text input or textarea)
   - Customization Grid (2-column on desktop, stack on mobile):
     - Left: Size dropdown + Color pickers (foreground/background)
     - Right: Live character count for text mode / URL validation indicator
   - Generate Button (prominent, full-width)

3. **QR Code Display Area**
   - Centered container with subtle shadow
   - Shows generated QR code or placeholder state
   - Max dimensions: 400x400px with padding

4. **Action Buttons**
   - Save as PNG (primary button)
   - Copy to Clipboard (secondary button, if implemented)
   - Positioned below QR display, horizontally aligned

5. **Footer Section**
   - Creator credit: "Created by Gazi Junaid"
   - LinkedIn link styled as subtle text link with icon
   - Centered, smaller text

### Form Elements
**Input Mode Toggle**:
- Segmented control with 2 options: "URL" | "Text"
- Active state: filled background
- Inactive state: transparent with border
- Smooth transition between states

**Text Input/Textarea**:
- Single-line input for URL mode (height: 48px)
- Multi-line textarea for Text mode (height: 120px, resizable)
- Border: 1px solid neutral
- Focus state: 2px border with accent color
- Rounded corners: 8px
- Placeholder text: "Enter URL..." or "Enter text (max 1000 characters)..."

**Dropdown (Size Selection)**:
- Options: 200×200, 256×256, 300×300, 400×400
- Height: 48px
- Custom styled select with arrow icon
- Label: "QR Code Size"

**Color Pickers**:
- Native HTML color input with custom wrapper
- Show current color value as hex code
- Labels: "Foreground Color" and "Background Color"
- Default previews: Black (#000000) and White (#FFFFFF)

**Generate Button**:
- Height: 52px, full-width
- Prominent visual weight
- Text: "Generate QR Code"
- Disabled state when input invalid

**Save Button**:
- Height: 48px
- Text: "Save as PNG"
- Disabled until QR code generated

### QR Code Display
- White background container
- Padding: `2rem`
- Subtle drop shadow for depth
- Placeholder state: Dashed border with text "Your QR code will appear here"
- Generated state: Centered QR code image with smooth fade-in

### Validation Feedback
- URL validation: Inline message below input (red for error, green for valid)
- Character counter for text mode: "245 / 1000 characters"
- Error messages: 13px, positioned below relevant input

---

## Responsive Behavior
**Desktop (>768px)**:
- Two-column customization grid
- QR code display max 400×400px
- Horizontal button layout

**Mobile (<768px)**:
- Stack all controls vertically
- Full-width buttons
- QR code scales to container (max 90vw)
- Reduce padding to `1rem`

---

## Images
**No hero image required** - This is a functional tool where controls should be immediately accessible without scrolling.

---

## Animations
**Minimal, purposeful only**:
- QR code appearance: 200ms fade-in
- Button interactions: subtle scale on click
- Toggle transitions: 150ms ease
- NO unnecessary scroll animations or decorative effects

---

## Quality Standards
- Crisp, pixel-perfect alignment
- Consistent 8px grid system
- High contrast for readability (WCAG AA minimum)
- Touch-friendly tap targets (min 44×44px)
- Clear visual hierarchy through size and weight, not color alone
- Professional, polished feel suitable for a portfolio piece