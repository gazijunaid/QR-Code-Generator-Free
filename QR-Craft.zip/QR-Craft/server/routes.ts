import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import QRCode from "qrcode";
import { z } from "zod";

const generateQRSchema = z.object({
  content: z.string().min(1, "Content is required").max(2000, "Content too long"),
  size: z.number().min(100).max(500).default(256),
  foregroundColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Invalid hex color").default("#000000"),
  backgroundColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Invalid hex color").default("#ffffff"),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/generate-qr", async (req, res) => {
    try {
      const validationResult = generateQRSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: validationResult.error.errors[0]?.message || "Invalid request data" 
        });
      }

      const { content, size, foregroundColor, backgroundColor } = validationResult.data;

      const dataUrl = await QRCode.toDataURL(content, {
        width: size,
        margin: 2,
        color: {
          dark: foregroundColor,
          light: backgroundColor,
        },
        errorCorrectionLevel: "M",
      });

      return res.json({ dataUrl });
    } catch (error) {
      console.error("QR code generation error:", error);
      return res.status(500).json({ message: "Failed to generate QR code" });
    }
  });

  return httpServer;
}
