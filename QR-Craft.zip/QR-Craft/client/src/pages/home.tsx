import { useState, useRef, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Link2, Type, Download, QrCode, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { SiLinkedin } from "react-icons/si";

type InputMode = "url" | "text";

interface QRCodeResponse {
  dataUrl: string;
}

const SIZE_OPTIONS = [
  { value: "200", label: "200 x 200" },
  { value: "256", label: "256 x 256" },
  { value: "300", label: "300 x 300" },
  { value: "400", label: "400 x 400" },
];

const MAX_TEXT_LENGTH = 1000;

function isValidUrl(string: string): boolean {
  try {
    const url = new URL(string);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

export default function Home() {
  const [inputMode, setInputMode] = useState<InputMode>("url");
  const [urlInput, setUrlInput] = useState("");
  const [textInput, setTextInput] = useState("");
  const [size, setSize] = useState("256");
  const [foregroundColor, setForegroundColor] = useState("#000000");
  const [backgroundColor, setBackgroundColor] = useState("#ffffff");
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const qrImageRef = useRef<HTMLImageElement>(null);
  const { toast } = useToast();

  const currentInput = inputMode === "url" ? urlInput : textInput;
  const isUrlValid = inputMode === "url" ? (urlInput.length === 0 || isValidUrl(urlInput)) : true;
  const isInputValid = inputMode === "url" 
    ? urlInput.length > 0 && isValidUrl(urlInput)
    : textInput.length > 0 && textInput.length <= MAX_TEXT_LENGTH;

  const generateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest<QRCodeResponse>("POST", "/api/generate-qr", {
        content: currentInput,
        size: parseInt(size),
        foregroundColor,
        backgroundColor,
      });
      return response;
    },
    onSuccess: (data) => {
      setQrDataUrl(data.dataUrl);
      toast({
        title: "QR Code Generated",
        description: "Your QR code has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate QR code. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = useCallback(() => {
    if (!isInputValid) return;
    generateMutation.mutate();
  }, [isInputValid, generateMutation]);

  const handleDownload = useCallback(() => {
    if (!qrDataUrl) return;
    
    const link = document.createElement("a");
    link.download = `qrcode-${Date.now()}.png`;
    link.href = qrDataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Download Started",
      description: "Your QR code is being downloaded.",
    });
  }, [qrDataUrl, toast]);

  const handleModeChange = (mode: InputMode) => {
    setInputMode(mode);
    setQrDataUrl(null);
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4 sm:py-12">
      <div className="max-w-[900px] mx-auto">
        <header className="text-center mb-8 sm:mb-12">
          <div className="inline-flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-md bg-primary/10">
              <QrCode className="w-8 h-8 text-primary" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-semibold text-foreground mb-2" data-testid="text-title">
            QR Code Generator
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base" data-testid="text-subtitle">
            Generate custom QR codes for URLs and text
          </p>
        </header>

        <Card className="p-6 sm:p-8 mb-6">
          <div className="space-y-6">
            <div>
              <Label className="text-sm font-medium mb-3 block">Input Mode</Label>
              <div className="inline-flex rounded-md border border-border p-1 gap-1">
                <Button
                  variant={inputMode === "url" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => handleModeChange("url")}
                  className="gap-2"
                  data-testid="button-mode-url"
                >
                  <Link2 className="w-4 h-4" />
                  URL
                </Button>
                <Button
                  variant={inputMode === "text" ? "default" : "ghost"}
                  size="sm"
                  onClick={() => handleModeChange("text")}
                  className="gap-2"
                  data-testid="button-mode-text"
                >
                  <Type className="w-4 h-4" />
                  Text
                </Button>
              </div>
            </div>

            <div>
              <Label htmlFor="input-field" className="text-sm font-medium mb-2 block">
                {inputMode === "url" ? "Website URL" : "Text Content"}
              </Label>
              {inputMode === "url" ? (
                <div className="space-y-2">
                  <Input
                    id="input-field"
                    type="url"
                    placeholder="https://example.com"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    className="h-12"
                    data-testid="input-url"
                  />
                  {urlInput.length > 0 && (
                    <div className="flex items-center gap-2 text-sm">
                      {isValidUrl(urlInput) ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />
                          <span className="text-green-600 dark:text-green-400" data-testid="text-url-valid">Valid URL</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-4 h-4 text-destructive" />
                          <span className="text-destructive" data-testid="text-url-invalid">Please enter a valid URL (include https://)</span>
                        </>
                      )}
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <Textarea
                    id="input-field"
                    placeholder="Enter text (max 1000 characters)..."
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value.slice(0, MAX_TEXT_LENGTH))}
                    className="min-h-[120px] resize-y"
                    data-testid="input-text"
                  />
                  <div className="flex items-center justify-between text-sm">
                    <span className={`${textInput.length > MAX_TEXT_LENGTH * 0.9 ? 'text-destructive' : 'text-muted-foreground'}`} data-testid="text-char-count">
                      {textInput.length} / {MAX_TEXT_LENGTH} characters
                    </span>
                    {textInput.length >= MAX_TEXT_LENGTH && (
                      <span className="text-destructive" data-testid="text-char-limit">Character limit reached</span>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              <div>
                <Label htmlFor="size-select" className="text-sm font-medium mb-2 block">
                  QR Code Size
                </Label>
                <Select value={size} onValueChange={setSize}>
                  <SelectTrigger id="size-select" className="h-12" data-testid="select-size">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent>
                    {SIZE_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value} data-testid={`option-size-${option.value}`}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="fg-color" className="text-sm font-medium mb-2 block">
                  Foreground Color
                </Label>
                <div className="flex items-center gap-3 h-12 px-3 border border-border rounded-md bg-background">
                  <input
                    id="fg-color"
                    type="color"
                    value={foregroundColor}
                    onChange={(e) => setForegroundColor(e.target.value)}
                    className="w-8 h-8 rounded-md border-0 cursor-pointer"
                    data-testid="input-fg-color"
                  />
                  <span className="text-sm font-mono text-muted-foreground uppercase" data-testid="text-fg-color">
                    {foregroundColor}
                  </span>
                </div>
              </div>

              <div>
                <Label htmlFor="bg-color" className="text-sm font-medium mb-2 block">
                  Background Color
                </Label>
                <div className="flex items-center gap-3 h-12 px-3 border border-border rounded-md bg-background">
                  <input
                    id="bg-color"
                    type="color"
                    value={backgroundColor}
                    onChange={(e) => setBackgroundColor(e.target.value)}
                    className="w-8 h-8 rounded-md border-0 cursor-pointer"
                    data-testid="input-bg-color"
                  />
                  <span className="text-sm font-mono text-muted-foreground uppercase" data-testid="text-bg-color">
                    {backgroundColor}
                  </span>
                </div>
              </div>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={!isInputValid || generateMutation.isPending}
              className="w-full h-[52px] text-base font-medium"
              data-testid="button-generate"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <QrCode className="w-5 h-5 mr-2" />
                  Generate QR Code
                </>
              )}
            </Button>
          </div>
        </Card>

        <Card className="p-6 sm:p-8 mb-6">
          <div className="flex flex-col items-center">
            {qrDataUrl ? (
              <div className="space-y-6 w-full flex flex-col items-center">
                <div 
                  className="bg-white p-6 rounded-md shadow-sm transition-opacity duration-200"
                  style={{ maxWidth: `${parseInt(size) + 48}px` }}
                >
                  <img
                    ref={qrImageRef}
                    src={qrDataUrl}
                    alt="Generated QR Code"
                    className="w-full h-auto"
                    data-testid="img-qr-code"
                  />
                </div>
                <Button
                  onClick={handleDownload}
                  variant="outline"
                  className="gap-2"
                  data-testid="button-download"
                >
                  <Download className="w-4 h-4" />
                  Save as PNG
                </Button>
              </div>
            ) : (
              <div 
                className="w-full max-w-[300px] aspect-square border-2 border-dashed border-border rounded-md flex flex-col items-center justify-center text-muted-foreground p-8"
                data-testid="placeholder-qr"
              >
                <QrCode className="w-12 h-12 mb-4 opacity-50" />
                <p className="text-center text-sm">Your QR code will appear here</p>
              </div>
            )}
          </div>
        </Card>

        <footer className="text-center py-6">
          <p className="text-sm text-muted-foreground mb-2" data-testid="text-creator">
            Created by <span className="font-medium text-foreground">Gazi Junaid</span>
          </p>
          <a
            href="http://www.linkedin.com/in/gazijunaid-gazijunaid"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-linkedin"
          >
            <SiLinkedin className="w-4 h-4" />
            Connect on LinkedIn
          </a>
        </footer>
      </div>
    </div>
  );
}
